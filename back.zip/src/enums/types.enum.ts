export enum PropertyTypes {
    HOUSE = 'house',
    APARTMENT = 'apartment',
    LAND = 'land',
    OFFICE = 'office',
    STORE = 'store',
    OTHER = 'other',
}
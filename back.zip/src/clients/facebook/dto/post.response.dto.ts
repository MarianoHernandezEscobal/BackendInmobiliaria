export class PostFacebook {
    created_time: string;
    message: string;
    id: string;
}
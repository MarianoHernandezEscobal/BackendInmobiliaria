export enum MESSAGES {
    USER_NOT_FOUND = 'Usuario no encontrado',
    PROPERTY_NOT_FOUND ='Propiedad no encontrada',
    RENT_NOT_FOUND = 'Alquiler no encontrado'
}
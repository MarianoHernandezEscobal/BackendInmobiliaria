module.exports = {
  apps: [
    {
      name: "nest-app",
      script: "npm",
      args: "run start",
      watch: true,
    },
  ],
};
